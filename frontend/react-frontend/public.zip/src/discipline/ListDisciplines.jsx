import React from 'react';
import { Link } from 'react-router-dom';

// импорт компонента Discipline
import Discipline from './Discipline';

import http from "../../http-common";

class ListDisciplines extends React.Component {
    // объект state описывает внутреннее состояние компонента (аналог data во Vue.js)
    state = {
        disciplines: [],
    };

    // обработчик, который срабатывает до вызова render() (во Vue аналог — mounted())
    componentWillMount() {
        http
            .get("/listDisciplines")
            .then(response => {
                // обновление состояния
                this.setState({ disciplines: response.data })
            })
            .catch(e => {
                console.log(e);
            });
    }

    render() {
        const { disciplines } = this.state;

        var list = [];
        for (var i in disciplines) {
            list.push(
                <Link to={`/discipline/${disciplines[i].id}`} param1={disciplines[i].id}>
                    <Discipline key={i} id={disciplines[i].id} content={disciplines[i].name}/>
                </Link>
            )
        }
        return (
            <div>
                <Link to={`/addDiscipline`}>Добавить дисциплину </Link>
                {list.length ? list : "Подождите, идёт загрузка данных"}
            </div>
        )
    }
}

export default ListDisciplines;