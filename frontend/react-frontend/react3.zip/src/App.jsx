import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

import Header from './layout/Header'
import ListDisciplines from './discipline/ListDisciplines.jsx'
import AddDiscipline from './discipline/AddDiscipline.jsx'
import DisciplineData from './discipline/DisciplineData.jsx'


class App extends React.Component {
    render() {
        return (
            <>
                <BrowserRouter>
                    <Header />
                    <Routes>
                        <Route path='/listDisciplines' element={<ListDisciplines/>} />
                        <Route path='/addDiscipline' element={<AddDiscipline/>} />
                        <Route path="/discipline/:id" element={<DisciplineData/>}/>
                    </Routes>
                </BrowserRouter>
            </>
        );
    }
}
export default App;